
# Polyfill-library

[The polyfill-library has been moved to it's own repository.](https://github.com/Financial-Times/polyfill-library)