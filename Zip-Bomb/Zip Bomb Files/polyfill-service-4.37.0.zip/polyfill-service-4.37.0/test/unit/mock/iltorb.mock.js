"use strict";

const sinon = require("sinon");

module.exports = {
	compress: sinon.stub().resolves()
};
