"use strict";

const process = require("process");

module.exports = {
	host: process.env.HOST || "https://polyfill.io"
};
